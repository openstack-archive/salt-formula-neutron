FUEL-utils
===========

Set of tool for maintance installed Openstack cluster

* **fuel-fdb-cleaner** -- utility for clean fdb table on compute and router
  nodes while active l3-agent migrate from one node to another.

