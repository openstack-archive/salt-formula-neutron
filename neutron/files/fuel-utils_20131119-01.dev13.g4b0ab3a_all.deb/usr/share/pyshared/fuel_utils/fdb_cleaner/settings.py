# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import eventlet
eventlet.monkey_patch()

LOG_NAME = 'neutron-fdb-cleaner'
API_VER = '2.0'

# vim: tabstop=4 shiftwidth=4 softtabstop=4